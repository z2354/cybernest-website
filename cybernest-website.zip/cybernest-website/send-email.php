<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name    = htmlspecialchars($_POST["name"]);
    $email   = htmlspecialchars($_POST["email"]);
    $message = htmlspecialchars($_POST["message"]);

    $to = "osanozedekiah@gmail.com";
    $subject = "New Contact Message - CyberNest Technologies";

    $body = "
    Name: $name
    Email: $email

    Message:
    $message
    ";

    $headers = "From: CyberNest Website <noreply@cybernest.co.ke>";

    mail($to, $subject, $body, $headers);

    echo "Message sent successfully ✅";
}
?>