<?php
$name    = urlencode($_POST['name']);
$email   = urlencode($_POST['email']);
$message = urlencode($_POST['message']);

$phone = "254798183089"; // ✅ Your WhatsApp number

$whatsappURL = "https://wa.me/$phone?text="
    . "New%20Message%20From%20CyberNest%20Website%0A%0A"
    . "Name:%20$name%0A"
    . "Email:%20$email%0A%0A"
    . "Message:%0A$message";

header("Location: $whatsappURL");
exit;