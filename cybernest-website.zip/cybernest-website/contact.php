<?php include "includes/header.php"; ?>

<section class="contact">
    <h2>Contact CyberNest Technologies</h2>

    <form action="send-whatsapp.php" method="POST">
        <input type="text" name="name" placeholder="Your Name" required>

        <input type="email" name="email" placeholder="Your Email" required>

        <textarea name="message" placeholder="Your Message" required></textarea>

        <button type="submit">Send Message</button>
    </form>

    <p class="note">
        Messages are sent directly to our WhatsApp for faster response.
    </p>
</section>

<?php include "includes/footer.php"; ?>