<?php include "includes/header.php"; ?>

<section class="hero">
    <h1>Secure, Smart, Scalable Solutions</h1>
    <p>
        We empower businesses and institutions with innovative IT services —
        from websites and apps to hardware and cloud solutions.
    </p>
    <a href="contact.php" class="btn">Get Started</a>
</section>

<section class="services">
    <h2>Our Services</h2>
    <ul>
        <li>Website Development</li>
        <li>School Management Systems</li>
        <li>Warehouse Management Systems</li>
        <li>Cloud Hosting & IT Support</li>
    </ul>
</section>

<?php include "includes/footer.php"; ?>