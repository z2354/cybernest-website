<footer>
    <p>&copy; 2026 CyberNest Technologies | Nairobi, Kenya</p>
</footer>

<script src="js/app.js"></script>
</body>
</html>