<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CyberNest Technologies</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
    <div class="logo">CyberNest Technologies</div>
    <nav>
        <a href="index.php">Home</a>
        <a href="contact.php">Contact</a>
    </nav>
</header>